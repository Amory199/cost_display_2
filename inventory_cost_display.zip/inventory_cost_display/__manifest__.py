{
    'name': 'Inventory Cost Display',
    'version': '18.0',
    'category': 'Inventory/Inventory',
    'summary': 'Display product costs in delivery and receipt line views',
    'description': """
        This module extends the inventory module to display product costs
        in the line views of delivery orders and receipt operations.
        
        Features:
        - Shows product cost in delivery order lines
        - Shows product cost in receipt operation lines
        - Configurable cost display permissions
        - Real-time cost calculation
    """,
    'author': 'Ashmawy w Amr',
    'depends': ['base','stock', 'product',],
    'data': [
        'views/stock_picking.xml',
    ],
    'installable': True,
}
